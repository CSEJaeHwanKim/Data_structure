#include "TVChannel.h"

CTVChannel::CTVChannel(void)
{
}

CTVChannel::~CTVChannel(void)
{
}

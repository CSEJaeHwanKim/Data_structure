#include <stdio.h>
#include "TVNode.h"

void main()
{
	/*
	CTVList		list;

	list.AddHead( "KBS1", 9, "http://kbs.com" );
	list.AddHead( "KBS2", 7 );
	list.AddHead( "MBC", 11 );
	list.AddHead( "SBS", 5 );
	list.Display();

	list.DeleteTail();
	list.DeletePos( 2 );
	list.Display();
	*/

/*
	CTVNode	a( "KBS1", 9, "http://kbs.com" );
	CTVNode	b( "KBS2", 7 );
	CTVNode c( "MBC", 11 );
	CTVNode	d( "SBS", 5 );
*/
	CTVNode	*a = new CTVNode( "KBS1", 9, "http://kbs.com" );
	CTVNode	*b = new CTVNode( "KBS2", 7 );
	CTVNode *c = new CTVNode( "MBC", 11 );
	CTVNode	*d = new CTVNode( "SBS", 5 );

	a->AddNext( b );
	b->AddNext( c );
	c->AddNext( d );
	a->PrintAll();

	printf("\n");

	a->DeleteNext();
	a->DeleteNext();
	a->PrintAll();

/*
	a.Print();
	b.Print();
	c.Print();
	d.Print();
*/
/*
	CTVList		list;

	list.AddTail( "KBS1", 9 );
	list.AddTail( "KBS2", 7 );
	list.AddTail( "MBC", 11 );
	list.AddHead( "SBS", 5 );

	list.Display( );

	list.AddHead( "JTBC", 17 );

	list.Delete( "MBC" );
	list.Display( );

	C???Node *node = list.Find("SBS");
*/
}
